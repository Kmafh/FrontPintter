package com.spring.printter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrintterApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrintterApplication.class, args);
	}

}
